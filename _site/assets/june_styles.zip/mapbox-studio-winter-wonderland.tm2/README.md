# Mapbox Outdoors - Winter Wonderland

Winterized Outdoors style for [Mapbox Studio](https://github.com/mapbox/mapbox-studio).
