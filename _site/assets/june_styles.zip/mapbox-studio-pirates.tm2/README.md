mapbox-studio-pirates.tm2
=========================

Mapbox Studio default style.
