super-mario
===========

an mario-inspired Mapbox Studio map
