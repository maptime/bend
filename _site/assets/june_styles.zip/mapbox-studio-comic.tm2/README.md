Comic Style
===========================
A style that pulls in typography and textures reminiscent of comic books

**Type**
[Komika Title](http://www.dafont.com/komika-title.font)
[Komika Hand](http://www.dafont.com/komika-hands.font)

![Pow!](http://www.ihatepresentations.com/wp-content/uploads/2013/01/pow.jpg)
