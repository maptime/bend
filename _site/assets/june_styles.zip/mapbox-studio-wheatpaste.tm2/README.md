# Wheatpaste

Wheatpaste style for [Mapbox Studio](https://www.mapbox.com/mapbox-studio/)